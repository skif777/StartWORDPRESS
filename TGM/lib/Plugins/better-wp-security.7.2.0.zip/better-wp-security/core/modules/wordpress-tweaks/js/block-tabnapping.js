document.addEventListener( 'DOMContentLoaded', function() {
	blankshield( document.querySelectorAll( 'a[target=_blank]' ) );
});
